package com.example.signquiz;

public class Database {

    Integer [] signs = {
            R.drawable.bear,
            R.drawable.sheep,
            R.drawable.speed_camera,
            R.drawable.horse,
            R.drawable.bike_route,
            R.drawable.combine_path,
            R.drawable.ethanol,
            R.drawable.motorcycle,
            R.drawable.truck_parking,
            R.drawable.pedestrians

    };
    String [] answers = {
            "Bear Crossing",
            "Sheep Crossing",
            "Speed Camera",
            "Horse Path",
            "Bike Route",
            "Combine Path",
            "Ethanol Available",
            "Motorcycle",
            "Truck Parking",
            "Pedestrian Path"
    };
}
